import turtle

t = turtle.Turtle()
t.forward(100)

print ("Teaching Python Editor")